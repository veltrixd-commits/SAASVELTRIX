# Veltrix - Deployment Package

## � SEEING BLACK & WHITE TEXT ONLY? READ THIS FIRST! 🚨

### YOUR SITE WAS BUILT FOR **SUBDOMAIN** DEPLOYMENT ONLY

**This means CSS won't load if you deploy to a subdirectory!**

---

## ✅ CORRECT WAY TO DEPLOY:

### Step 1: Create a Subdomain in cPanel
1. Go to cPanel → **Domains** → **Subdomains**
2. Create subdomain: **demo** (or any name you want)
3. Document root will be: `public_html/demo` or similar

### Step 2: Upload Files to Subdomain Folder
1. Go to **File Manager**
2. Navigate to your **subdomain's root folder** (e.g., `public_html/demo`)
3. **DELETE** any existing files
4. Upload this ZIP file
5. Right-click → **Extract**
6. Move all files from extracted folder to the subdomain root

### Step 3: Verify .htaccess File
1. In File Manager, click **Settings** (top right)
2. Enable "**Show Hidden Files (dotfiles)**"
3. Verify you can see **`.htaccess`** file
4. Permissions should be **644**

### Step 4: Test Your Site
Visit: `https://demo.yourdomain.com` (or your subdomain name)

**Expected Result:** Full colors, gradients, styling, responsive design ✅

---

## ❌ WRONG WAY (Don't do this):

### Deploying to Subdirectory: `yourdomain.com/demo`
**This will NOT work with the current build!**

The site was built with absolute paths (starting with `/`), which means:
- HTML tries to load CSS from: `/next/static/css/...` (site root)
- But in subdirectory, file is at: `/demo/_next/static/css/...`
- Result: **CSS not found = black & white text**

**If you MUST use subdirectory:**
1. Edit `next.config.js` and uncomment: `basePath: '/demo'`
2. Run: `npm run build`
3. Create new ZIP
4. Deploy to subdirectory

---

## 🔧 DIAGNOSTIC TEST

If you still have issues after following instructions:

1. Upload **`test-css-loading.html`** (included in this ZIP) to your server
2. Visit: `https://demo.yourdomain.com/test-css-loading.html`
3. It will show you exactly what's wrong

---

## 📁 Expected File Structure (Subdomain Root)

```
public_html/demo/  (your subdomain folder)
├── .htaccess          ← MUST BE HERE!
├── index.html
├── test-css-loading.html
├── _next/
│   └── static/
│       ├── css/
│       │   └── e1b28a67dbdbce07.css  ← CSS FILE
│       └── chunks/
├── dashboard/
├── pricing/
├── login/
└── signup/
```

---

## ✅ Success Checklist

- [ ] Created subdomain in cPanel (not just a folder!)
- [ ] Uploaded files to subdomain root (not main site folder)
- [ ] .htaccess file exists and is visible
- [ ] Can access: `https://demo.yourdomain.com/_next/static/css/e1b28a67dbdbce07.css`
- [ ] Tested in multiple browsers
- [ ] Cleared browser cache (Ctrl+Shift+Delete)

---

## 🆘 Still Not Working?

### Test CSS File Directly:
Try accessing: `https://demo.yourdomain.com/_next/static/css/e1b28a67dbdbce07.css`

**If you get 404:** CSS file path is wrong - you deployed to subdirectory instead of subdomain
**If you get 403:** Permissions issue - chmod 644 for files, 755 for folders  
**If you see CSS code:** File loads! Clear your browser cache

### Contact Host Africa Support:

```
Subject: Enable Apache Modules for Static Site

Please enable these modules for my subdomain:
- mod_rewrite
- mod_mime  
- mod_deflate
- mod_expires
- mod_headers

Also confirm:
- .htaccess files are enabled
- AllowOverride directive is set to "All"

Subdomain: demo.yourdomain.com
Folder: [your path]
```

---

## 📱 Responsive Design

This site is fully responsive:
- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

All breakpoints are in the CSS file. If CSS doesn't load, responsive design won't work!

---

**Built with:** Next.js 14 • React 18 • Tailwind CSS

**Important:** This build uses **absolute paths** for assets. It ONLY works when deployed to a subdomain or site root, NOT a subdirectory!
